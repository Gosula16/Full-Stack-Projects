import express from "express";
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from "mongoose";
import router from './routes.js'

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());

app.use('/api/sensors',router);

mongoose.connect(process.env.MONGO_URI)
    .then(console.log("Mongo Connected"))
    .catch((err)=>{console.log(err)});

app.listen(5000,()=>{console.log("Server Started Successfully")});
